import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

/** Consistent page title row used across all top-level screens. */
export function PageHeader({
  title,
  subtitle,
  actions,
  className,
  icon: Icon,
}: {
  title: string;
  subtitle?: ReactNode;
  actions?: ReactNode;
  className?: string;
  icon?: React.ComponentType<{ size?: number; className?: string }>;
}) {
  return (
    <div
      className={cn(
        'flex flex-wrap items-start justify-between gap-x-4 gap-y-2 border-b border-line bg-surface-1 px-4 py-3.5',
        className,
      )}
    >
      <div className="min-w-0">
        <h1 className="flex items-center gap-2.5 text-xl font-bold tracking-tight text-ink">
          {Icon && <Icon size={20} className="text-brand" aria-hidden />}
          {title}
        </h1>
        {subtitle && <div className="mt-1 text-sm text-ink-muted">{subtitle}</div>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-1.5">{actions}</div>}
    </div>
  );
}
