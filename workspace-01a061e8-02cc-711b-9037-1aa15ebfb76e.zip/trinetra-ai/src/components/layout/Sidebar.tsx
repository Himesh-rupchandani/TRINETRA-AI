import { NavLink } from 'react-router-dom';
import {
  Activity,
  Bell,
  Car,
  Cctv,
  LayoutDashboard,
  ListTree,
  Map,
  ScrollText,
  ShieldCheck,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAlerts } from '@/hooks/useAlerts';

interface NavItem {
  to: string;
  label: string;
  /** One line explaining what the page is for, shown under the label. */
  hint: string;
  icon: typeof LayoutDashboard;
  badge?: 'alerts';
  end?: boolean;
}

const NAV: { section: string; items: NavItem[] }[] = [
  {
    section: 'Daily work',
    items: [
      { to: '/', label: 'Home', hint: "Today's summary", icon: LayoutDashboard, end: true },
      { to: '/vehicles', label: 'Find a Vehicle', hint: 'Search by number plate', icon: Car },
      { to: '/alerts', label: 'Alerts', hint: 'Needs your action', icon: Bell, badge: 'alerts' },
      { to: '/cameras', label: 'Live Cameras', hint: 'Watch any camera', icon: Cctv },
      { to: '/gis', label: 'Map', hint: 'Cameras and routes', icon: Map },
      { to: '/events', label: 'Vehicle Log', hint: 'Every vehicle seen', icon: ListTree },
    ],
  },
  {
    section: 'Records',
    items: [
      { to: '/watchlist', label: 'Wanted List', hint: 'Vehicles being watched', icon: ShieldCheck },
      { to: '/registry', label: 'Camera List', hint: 'All camera details', icon: ScrollText },
      { to: '/system', label: 'System Status', hint: 'Is everything working?', icon: Activity },
    ],
  },
];

export function Sidebar({
  open,
  onClose,
  collapsed,
}: {
  open: boolean;
  onClose: () => void;
  collapsed: boolean;
}) {
  const { counts } = useAlerts();

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/60 lg:hidden"
          onClick={onClose}
          aria-hidden
        />
      )}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 flex flex-col border-r border-line bg-surface-1 transition-[width,transform] duration-200',
          collapsed ? 'w-[64px]' : 'w-[236px]',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
        )}
        aria-label="Primary navigation"
      >
        <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-3">
          <div
            className="grid h-7 w-7 shrink-0 place-items-center rounded-sm border border-brand/40 bg-brand/10"
            aria-hidden
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4 text-brand" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M12 3 3 7.5v4.2c0 5 3.8 8.6 9 9.3 5.2-.7 9-4.3 9-9.3V7.5L12 3Z" />
              <circle cx="12" cy="11" r="2.6" />
            </svg>
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="truncate text-xs font-bold tracking-[0.14em] text-ink">TRINETRA</p>
              <p className="truncate text-[9px] uppercase tracking-[0.18em] text-ink-faint">
                AI Control Room
              </p>
            </div>
          )}
          <button
            type="button"
            className="btn-ghost btn-xs ml-auto lg:hidden"
            onClick={onClose}
            aria-label="Close navigation"
          >
            <X size={13} aria-hidden />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-2">
          {NAV.map((group) => (
            <div key={group.section} className="mb-2">
              {!collapsed && (
                <p className="px-3 pb-1.5 pt-3 text-2xs font-semibold uppercase tracking-[0.12em] text-ink-faint">
                  {group.section}
                </p>
              )}
              <ul>
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const badgeCount = item.badge === 'alerts' ? counts.ACTIVE : 0;
                  return (
                    <li key={item.to}>
                      <NavLink
                        to={item.to}
                        end={item.end}
                        onClick={onClose}
                        title={collapsed ? `${item.label} — ${item.hint}` : undefined}
                        className={({ isActive }) =>
                          cn(
                            'relative mx-1.5 flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors',
                            isActive
                              ? 'bg-brand/12 text-brand'
                              : 'text-ink-muted hover:bg-surface-3 hover:text-ink',
                          )
                        }
                      >
                        {({ isActive }) => (
                          <>
                            {isActive && (
                              <span className="absolute -left-1.5 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-brand" aria-hidden />
                            )}
                            <Icon size={18} className="shrink-0" aria-hidden />
                            {!collapsed && (
                              <span className="min-w-0 flex-1">
                                <span className="block truncate leading-tight">{item.label}</span>
                                <span className="block truncate text-2xs font-normal text-ink-faint">
                                  {item.hint}
                                </span>
                              </span>
                            )}
                            {badgeCount > 0 && (
                              <span
                                className={cn(
                                  'ml-auto rounded bg-critical px-1.5 font-mono text-2xs font-bold leading-5 text-white',
                                  collapsed && 'absolute right-0.5 top-0.5 ml-0 px-0.5',
                                )}
                                aria-label={`${badgeCount} active alerts`}
                              >
                                {badgeCount}
                              </span>
                            )}
                          </>
                        )}
                      </NavLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {!collapsed && (
          <div className="border-t border-line p-2.5">
            <p className="text-2xs leading-relaxed text-ink-faint">
              Hybrid CCTV Intelligence
              <br />
              Model 1 · Registry &amp; GIS
              <br />
              Model 2 · Viewing &amp; Analytics
            </p>
          </div>
        )}
      </aside>
    </>
  );
}
