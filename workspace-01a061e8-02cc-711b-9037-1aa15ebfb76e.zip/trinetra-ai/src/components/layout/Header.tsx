import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import {
  Bell,
  Menu,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Radio,
  Search,
  Sun,
  UserRound,
} from 'lucide-react';
import { cn, normalisePlate } from '@/lib/utils';
import { useClock } from '@/hooks/useUi';
import { useAlerts } from '@/hooks/useAlerts';
import { useLiveEvents } from '@/hooks/useLiveEvents';
import { useTheme } from '@/features/system/ThemeProvider';
import { config } from '@/lib/config';

const CONNECTION_TONE: Record<string, string> = {
  LIVE: 'text-online',
  SIMULATED: 'text-processing',
  CONNECTING: 'text-degraded',
  OFFLINE: 'text-offline',
};

export function Header({
  onMenu,
  onToggleCollapse,
  collapsed,
}: {
  onMenu: () => void;
  onToggleCollapse: () => void;
  collapsed: boolean;
}) {
  const navigate = useNavigate();
  const now = useClock();
  const { counts } = useAlerts();
  const { connection } = useLiveEvents();
  const { theme, toggle } = useTheme();
  const [quick, setQuick] = useState('');

  const submitQuick = (e: React.FormEvent) => {
    e.preventDefault();
    const p = normalisePlate(quick);
    if (p) navigate(`/vehicles/${p}`);
  };

  return (
    <header className="sticky top-0 z-20 flex h-12 shrink-0 items-center gap-2 border-b border-line bg-surface-1 px-2 sm:px-3">
      <button type="button" className="btn-ghost btn-xs lg:hidden" onClick={onMenu} aria-label="Open navigation">
        <Menu size={14} aria-hidden />
      </button>
      <button
        type="button"
        className="btn-ghost btn-xs hidden lg:inline-flex"
        onClick={onToggleCollapse}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <PanelLeftOpen size={14} aria-hidden /> : <PanelLeftClose size={14} aria-hidden />}
      </button>

      <div className="min-w-0">
        <h1 className="truncate text-sm font-bold leading-tight tracking-[0.16em] text-ink">
          {config.appName}
        </h1>
        <p className="hidden truncate text-[10px] leading-tight tracking-wide text-ink-faint sm:block">
          {config.tagline}
        </p>
      </div>

      {/* Global plate search — the hero entry point, reachable from every screen */}
      <form onSubmit={submitQuick} className="ml-2 hidden max-w-xs flex-1 md:block" role="search">
        <label htmlFor="global-plate-search" className="sr-only">
          Trace registration number
        </label>
        <div className="relative">
          <Search size={13} className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-ink-faint" aria-hidden />
          <input
            id="global-plate-search"
            value={quick}
            onChange={(e) => setQuick(e.target.value.toUpperCase())}
            placeholder="Search a number plate, e.g. GJ01AB1234"
            className="input pl-7 font-mono uppercase"
            autoComplete="off"
            spellCheck={false}
          />
        </div>
      </form>

      <div className="ml-auto flex items-center gap-1.5 sm:gap-2.5">
        {config.useMocks && (
          <span className="chip hidden border-degraded/45 bg-degraded/10 text-degraded xl:inline-flex">
            Demo Data
          </span>
        )}

        <span
          className={cn('hidden items-center gap-1 text-2xs font-semibold uppercase tracking-wider sm:inline-flex', CONNECTION_TONE[connection])}
          title={`Realtime channel: ${connection}`}
        >
          <Radio size={12} className={connection === 'OFFLINE' ? '' : 'animate-pulse'} aria-hidden />
          {connection === 'SIMULATED'
            ? 'Demo feed'
            : connection === 'LIVE'
              ? 'Live'
              : connection === 'CONNECTING'
                ? 'Connecting'
                : 'Offline'}
        </span>

        <button
          type="button"
          onClick={() => navigate('/alerts')}
          className={cn(
            'relative inline-flex h-8 items-center gap-1.5 rounded border px-2 text-2xs font-bold uppercase tracking-wider transition-colors',
            counts.ACTIVE > 0
              ? 'border-critical/50 bg-critical/12 text-critical hover:bg-critical/20'
              : 'border-line text-ink-muted hover:bg-surface-3',
          )}
          aria-label={`${counts.ACTIVE} alerts need your attention — open Alerts`}
        >
          <Bell size={13} className={counts.ACTIVE > 0 ? 'animate-pulse' : ''} aria-hidden />
          <span className="tabular-nums">{counts.ACTIVE}</span>
          <span className="hidden lg:inline">Active</span>
        </button>

        <div className="hidden text-right font-mono leading-tight sm:block">
          <p className="text-xs font-semibold tabular-nums text-ink">
            {now.toLocaleTimeString('en-GB', { hour12: false })}
          </p>
          <p className="text-[10px] text-ink-faint">
            {now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })} IST
          </p>
        </div>

        <button
          type="button"
          className="btn-ghost btn-xs"
          onClick={toggle}
          aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
        >
          {theme === 'dark' ? <Sun size={13} aria-hidden /> : <Moon size={13} aria-hidden />}
        </button>

        <div className="flex items-center gap-1.5 border-l border-line pl-2">
          <div className="grid h-7 w-7 place-items-center rounded-full border border-line bg-surface-3" aria-hidden>
            <UserRound size={14} className="text-ink-muted" />
          </div>
          <div className="hidden leading-tight xl:block">
            <p className="text-2xs font-semibold text-ink">Ctrl. Operator</p>
            <p className="text-[10px] text-ink-faint">Ahmedabad CCC</p>
          </div>
        </div>
      </div>
    </header>
  );
}
