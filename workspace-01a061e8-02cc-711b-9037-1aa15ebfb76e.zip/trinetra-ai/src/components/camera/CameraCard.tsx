import { memo } from 'react';
import { Link } from 'react-router-dom';
import { Activity, MapPin, Maximize2, Video } from 'lucide-react';
import type { Camera } from '@/types';
import { StatusChip } from '@/components/common/Chips';
import { cn, formatTime, relativeTime } from '@/lib/utils';

interface Props {
  camera: Camera;
  onView?: (camera: Camera) => void;
  compact?: boolean;
  selected?: boolean;
}

/**
 * Registry card. Deliberately does NOT mount a stream — feeds are only
 * loaded when an operator explicitly opens one (see performance notes).
 */
export const CameraCard = memo(function CameraCard({ camera, onView, compact, selected }: Props) {
  return (
    <article
      className={cn(
        'panel group flex flex-col transition-colors hover:border-line-strong',
        selected && 'border-brand/60 ring-1 ring-brand/30',
      )}
    >
      <div className="flex items-start justify-between gap-2 border-b border-line px-2.5 py-2">
        <div className="min-w-0">
          <div className="ml-auto flex items-center gap-1.5">
            <Video size={13} className="shrink-0 text-ink-faint" aria-hidden />
            <h3 className="truncate font-mono text-xs font-bold text-ink">{camera.name}</h3>
          </div>
          <p className="mt-0.5 flex items-center gap-1 truncate text-2xs text-ink-muted">
            <MapPin size={10} className="shrink-0" aria-hidden />
            {camera.location}
          </p>
        </div>
        <StatusChip status={camera.status} />
      </div>

      {!compact && (
        <dl className="grid grid-cols-2 gap-x-2 gap-y-1 px-2.5 py-2 text-2xs">
          <dt className="text-ink-faint">Department</dt>
          <dd className="truncate text-right text-ink-muted">{camera.department ?? '—'}</dd>
          <dt className="text-ink-faint">Video format</dt>
          <dd className="text-right font-mono text-ink-muted">{camera.codec ?? '—'}</dd>
          <dt className="text-ink-faint">Picture size</dt>
          <dd className="text-right font-mono text-ink-muted">
            {camera.width ? `${camera.width}×${camera.height}` : '—'}
          </dd>
          <dt className="text-ink-faint">Last vehicle</dt>
          <dd className="text-right font-mono text-ink-muted">
            {camera.lastEventAt ? formatTime(camera.lastEventAt) : '—'}
          </dd>
        </dl>
      )}

      <div className="mt-auto flex flex-wrap items-center justify-between gap-x-2 gap-y-1.5 border-t border-line px-2.5 py-2">
        <span
          className="flex items-center gap-1.5 whitespace-nowrap text-2xs text-ink-faint"
          title="Vehicles seen by this camera in the last 24 hours"
        >
          <Activity size={12} aria-hidden />
          {camera.eventCount24h ?? 0} {(camera.eventCount24h ?? 0) === 1 ? 'vehicle' : 'vehicles'} · {relativeTime(camera.lastEventAt)}
        </span>
        <div className="ml-auto flex items-center gap-1.5">
          {onView && (
            <button
              type="button"
              className="btn-ghost btn-xs"
              onClick={() => onView(camera)}
              title="Quick look without leaving this page"
            >
              <Maximize2 size={12} aria-hidden /> Quick look
            </button>
          )}
          <Link to={`/cameras/${camera.id}`} className="btn-primary btn-xs">
            Open camera
          </Link>
        </div>
      </div>
    </article>
  );
});
