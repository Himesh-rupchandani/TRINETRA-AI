import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, CheckCircle2, FileImage, Map, Siren } from 'lucide-react';
import type { Alert } from '@/types';
import { AlertStatusChip, SeverityChip } from '@/components/common/Chips';
import { PlateLink } from '@/components/common/Links';
import { ConfirmDialog } from '@/components/common/Modal';
import { useToast } from '@/features/system/ToastProvider';
import { cn, formatTime, relativeTime, severityBar } from '@/lib/utils';

export function AlertCard({
  alert,
  onAcknowledge,
  onResolve,
  onViewEvidence,
  compact = false,
}: {
  alert: Alert;
  onAcknowledge: (id: string) => Promise<void>;
  onResolve?: (id: string) => Promise<void>;
  onViewEvidence?: (alert: Alert) => void;
  compact?: boolean;
}) {
  const navigate = useNavigate();
  const toast = useToast();
  const [confirmResolve, setConfirmResolve] = useState(false);
  const [busy, setBusy] = useState(false);

  const ack = async () => {
    setBusy(true);
    try {
      await onAcknowledge(alert.id);
      toast.success('Alert acknowledged', `${alert.plate} · ${alert.cameraName ?? alert.cameraId}`);
    } catch {
      toast.error('Could not acknowledge alert');
    } finally {
      setBusy(false);
    }
  };

  const resolve = async () => {
    setConfirmResolve(false);
    setBusy(true);
    try {
      await onResolve?.(alert.id);
      toast.success('Alert resolved', `${alert.plate} closed by operator`);
    } catch {
      toast.error('Could not resolve alert');
    } finally {
      setBusy(false);
    }
  };

  return (
    <article
      className={cn(
        'panel relative overflow-hidden',
        alert.status === 'NEW' && alert.severity === 'CRITICAL' && 'animate-pulse-ring',
      )}
      aria-label={`${alert.severity} alert for ${alert.plate}`}
    >
      <span className={cn('absolute inset-y-0 left-0 w-1', severityBar[alert.severity])} aria-hidden />

      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-line py-2 pl-3.5 pr-2.5">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-2xs font-bold uppercase tracking-widest text-ink">
            <Siren size={12} className={alert.status === 'NEW' ? 'text-critical' : 'text-ink-faint'} aria-hidden />
            {alert.category}
          </p>
          <p className="mt-0.5 text-[10px] text-ink-faint">
            {formatTime(alert.createdAt)} · {relativeTime(alert.createdAt)}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <SeverityChip severity={alert.severity} />
          <AlertStatusChip status={alert.status} />
        </div>
      </div>

      <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 py-2 pl-3.5 pr-2.5 sm:grid-cols-4">
        <div>
          <dt className="kv-label">Vehicle</dt>
          <dd>
            <PlateLink plate={alert.plate} size="sm" />
          </dd>
        </div>
        <div>
          <dt className="kv-label">Camera</dt>
          <dd className="kv-value font-mono">{alert.cameraName ?? alert.cameraId.toUpperCase()}</dd>
        </div>
        <div className="col-span-2 sm:col-span-1">
          <dt className="kv-label">Place</dt>
          <dd className="kv-value truncate">{alert.location}</dd>
        </div>
        <div>
          <dt className="kv-label">Plate match</dt>
          <dd className="kv-value font-mono tabular-nums">
            {alert.confidence != null ? `${alert.confidence.toFixed(1)}%` : '—'}
          </dd>
        </div>
      </dl>

      {!compact && (alert.acknowledgedBy || alert.note) && (
        <p className="border-t border-line/60 py-1.5 pl-3.5 pr-2.5 text-2xs text-ink-faint">
          {alert.acknowledgedBy && <>Seen by {alert.acknowledgedBy}. </>}
          {alert.note}
        </p>
      )}

      <div className="flex flex-wrap items-center gap-1.5 border-t border-line py-1.5 pl-3.5 pr-2.5">
        <button type="button" className="btn-primary btn-xs" onClick={() => navigate(`/vehicles/${alert.plate}`)}>
          Look up this vehicle
        </button>
        <button type="button" className="btn-ghost btn-xs" onClick={() => navigate(`/cameras/${alert.cameraId}`)}>
          <Camera size={11} aria-hidden /> Open camera
        </button>
        <button
          type="button"
          className="btn-ghost btn-xs"
          onClick={() => navigate(`/gis?plate=${alert.plate}&focus=${alert.cameraId}`)}
        >
          <Map size={11} aria-hidden /> Show on map
        </button>
        {onViewEvidence && (
          <button type="button" className="btn-ghost btn-xs" onClick={() => onViewEvidence(alert)}>
            <FileImage size={11} aria-hidden /> See photo
          </button>
        )}
        <div className="ml-auto flex gap-1.5">
          {alert.status === 'NEW' && (
            <button type="button" className="btn-danger btn-xs" onClick={ack} disabled={busy}>
              <CheckCircle2 size={11} aria-hidden /> Mark as seen
            </button>
          )}
          {alert.status === 'ACKNOWLEDGED' && onResolve && (
            <button type="button" className="btn-ghost btn-xs" onClick={() => setConfirmResolve(true)} disabled={busy}>
              Close alert
            </button>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={confirmResolve}
        title="Close this alert?"
        message={`This closes the ${alert.category.toLowerCase()} alert for ${alert.plate} at ${alert.cameraName ?? alert.cameraId}. It stays in the alert history, but stops asking for your attention.`}
        confirmLabel="Yes, close it"
        onConfirm={resolve}
        onCancel={() => setConfirmResolve(false)}
      />
    </article>
  );
}
