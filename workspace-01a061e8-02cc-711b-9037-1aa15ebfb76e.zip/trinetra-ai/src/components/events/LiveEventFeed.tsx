import { memo } from 'react';
import { Link } from 'react-router-dom';
import { Pause, Play, ShieldAlert } from 'lucide-react';
import type { VehicleEvent } from '@/types';
import { PlateLink } from '@/components/common/Links';
import { EmptyState } from '@/components/common/Panel';
import { cn, formatTime, confidenceClass } from '@/lib/utils';
import { useLiveEvents } from '@/hooks/useLiveEvents';

const TYPE_LABEL: Record<string, string> = {
  VEHICLE_DETECTION: 'Vehicle',
  ANPR_READ: 'Plate read',
  WATCHLIST_MATCH: 'Wanted!',
  CAMERA_OFFLINE: 'Camera off',
  CAMERA_RECOVERED: 'Camera back',
  SPEED_VIOLATION: 'Speeding',
  WRONG_WAY: 'Wrong way',
};

export const EventRow = memo(function EventRow({ event }: { event: VehicleEvent }) {
  const watch = event.watchlistMatch;
  return (
    <li
      className={cn(
        'flex items-center gap-2 border-b border-line/60 px-2 py-1.5 text-xs transition-colors hover:bg-surface-2',
        watch && 'bg-critical/[0.07]',
      )}
    >
      <time className="w-[58px] shrink-0 font-mono text-2xs tabular-nums text-ink-faint" dateTime={event.timestamp}>
        {formatTime(event.timestamp)}
      </time>
      <Link
        to={`/cameras/${event.cameraId}`}
        title={event.location}
        className="w-[48px] shrink-0 font-mono text-2xs text-ink-muted hover:text-brand"
      >
        {event.cameraName ?? event.cameraId.toUpperCase()}
      </Link>
      <PlateLink plate={event.plate} size="xs" className="w-[86px] shrink-0" />
      <span
        className={cn(
          'ml-auto w-[38px] shrink-0 text-right font-mono text-2xs tabular-nums',
          confidenceClass(event.plateConfidence),
        )}
      >
        {event.plateConfidence ? `${event.plateConfidence.toFixed(0)}%` : '—'}
      </span>
      <span
        className={cn(
          'flex w-[54px] shrink-0 items-center justify-end gap-0.5 text-[10px] font-bold uppercase tracking-wide',
          watch ? 'text-critical' : 'text-ink-faint',
        )}
      >
        {watch && <ShieldAlert size={9} aria-hidden />}
        {TYPE_LABEL[event.eventType] ?? event.eventType}
      </span>
    </li>
  );
});

/** Rolling detection feed fed by the realtime channel (simulated in mock mode). */
export function LiveEventFeed({
  seed = [],
  max = 40,
  className,
}: {
  seed?: VehicleEvent[];
  max?: number;
  className?: string;
}) {
  const { events, paused, setPaused } = useLiveEvents();
  const combined = [...events, ...seed]
    .filter((e, i, arr) => arr.findIndex((x) => x.id === e.id) === i)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, max);

  return (
    <div className={cn('flex h-full min-h-0 flex-col', className)}>
      <div className="flex items-center justify-between gap-2 border-b border-line px-2.5 py-1 text-[10px] uppercase tracking-wider text-ink-faint">
        <span className="flex items-center gap-1.5">
          <span className={cn('h-1.5 w-1.5 rounded-full', paused ? 'bg-ink-faint' : 'bg-online animate-pulse')} aria-hidden />
          {paused ? 'Paused' : 'Live now'}
        </span>
        <button
          type="button"
          className="btn-ghost btn-xs"
          onClick={() => setPaused(!paused)}
          aria-label={paused ? 'Resume live feed' : 'Pause live feed'}
        >
          {paused ? <Play size={10} aria-hidden /> : <Pause size={10} aria-hidden />}
          {paused ? 'Resume' : 'Pause'}
        </button>
      </div>
      {combined.length === 0 ? (
        <EmptyState title="Awaiting detections" detail="Live vehicle events will appear here as cameras report." />
      ) : (
        <ul className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden" aria-label="Live event feed">
          {combined.map((e) => (
            <EventRow key={e.id} event={e} />
          ))}
        </ul>
      )}
    </div>
  );
}
