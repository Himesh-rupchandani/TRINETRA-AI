import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

type Tone = 'neutral' | 'online' | 'critical' | 'brand' | 'warn';

const TONES: Record<Tone, { value: string; accent: string }> = {
  neutral: { value: 'text-ink', accent: 'bg-line-strong' },
  online: { value: 'text-online', accent: 'bg-online' },
  critical: { value: 'text-critical', accent: 'bg-critical' },
  brand: { value: 'text-brand', accent: 'bg-brand' },
  warn: { value: 'text-degraded', accent: 'bg-degraded' },
};

export function KpiCard({
  label,
  value,
  sub,
  tone = 'neutral',
  icon: Icon,
  to,
  loading,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: Tone;
  icon?: React.ComponentType<{ size?: number; className?: string }>;
  to?: string;
  loading?: boolean;
}) {
  const t = TONES[tone];
  const body = (
    <div className="panel relative flex h-full items-center gap-3 overflow-hidden px-3 py-2.5 transition-colors hover:border-line-strong">
      <span className={cn('absolute inset-y-0 left-0 w-1', t.accent)} aria-hidden />
      {Icon && <Icon size={20} className="shrink-0 text-ink-faint" aria-hidden />}
      <div className="min-w-0 flex-1">
        <p className="text-2xs font-semibold leading-tight text-ink-muted">{label}</p>
        {loading ? (
          <div className="skeleton mt-1 h-6 w-12" />
        ) : (
          <p className={cn('font-mono text-2xl font-bold leading-tight tabular-nums', t.value)}>
            {value}
          </p>
        )}
        {sub && <p className="text-2xs leading-snug text-ink-faint">{sub}</p>}
      </div>
    </div>
  );

  return to ? (
    <Link to={to} className="block h-full focus-visible:rounded">
      {body}
    </Link>
  ) : (
    body
  );
}
