/**
 * The four things an officer does most often, in the order they usually do
 * them. Doubles as the guided demo walkthrough.
 */
export interface DemoStep {
  step: number;
  label: string;
  to: string;
  hint: string;
}

export const DEMO_PLATE = 'GJ01AB1234';

export const demoFlow: DemoStep[] = [
  {
    step: 1,
    label: 'Watch a camera',
    to: '/cameras/cam04',
    hint: 'Open the live view for Paldi Circle',
  },
  {
    step: 2,
    label: 'Look up a vehicle',
    to: `/vehicles/${DEMO_PLATE}`,
    hint: `See everywhere ${DEMO_PLATE} has been seen`,
  },
  {
    step: 3,
    label: 'See its route on a map',
    to: `/gis?plate=${DEMO_PLATE}`,
    hint: 'Follow the vehicle from camera to camera',
  },
  {
    step: 4,
    label: 'Check alerts',
    to: '/alerts',
    hint: 'Confirm you have seen each alert',
  },
];
