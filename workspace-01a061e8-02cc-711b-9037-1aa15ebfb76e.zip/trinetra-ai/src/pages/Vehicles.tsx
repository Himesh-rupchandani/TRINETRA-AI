import { useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowRight, Car, MapPin, Route, ShieldAlert, ShieldCheck } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { TraceSearchBar } from '@/components/vehicle/TraceSearchBar';
import { Panel, EmptyState, LoadingState, ErrorState } from '@/components/common/Panel';
import { SeverityChip } from '@/components/common/Chips';
import { PlateLink } from '@/components/common/Links';
import { useVehicleSearch } from '@/hooks/useVehicleSearch';
import { useAsync } from '@/hooks/useAsync';
import { vehicleService } from '@/services/vehicleService';
import { formatDateTime, formatTime, prettyPlate } from '@/lib/utils';

/**
 * VEHICLE SEARCH — the hero screen.
 * Registration number in, watchlist verdict + sightings out, one click to
 * the full investigation workspace.
 */
export default function Vehicles() {
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const { result, loading, error, searched, trace } = useVehicleSearch();
  const watchlist = useAsync(() => vehicleService.watchlist(), []);
  const initial = params.get('plate') ?? '';

  useEffect(() => {
    if (initial) void trace(initial);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial]);

  const onTrace = (plate: string) => {
    setParams({ plate });
    void trace(plate);
  };

  const wl = result?.profile?.watchlist;
  const sightings = useMemo(() => result?.events ?? [], [result]);

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Find a Vehicle"
        icon={Car}
        subtitle="Type a number plate to see everywhere it has been seen."
      />

      <div className="min-h-0 flex-1 overflow-auto">
        <div className="mx-auto max-w-5xl p-3 sm:p-5">
          <section className="panel p-4 sm:p-5">
            <h2 className="text-lg font-semibold text-ink">Which vehicle are you looking for?</h2>
            <p className="mt-1 text-sm text-ink-muted">
              Enter the number plate. We will check all 30 cameras and show you every place it
              has been seen, in order, on a map.
            </p>
            <div className="mt-2.5">
              <TraceSearchBar initialValue={initial} onTrace={onTrace} loading={loading} size="lg" />
            </div>
          </section>

          {loading && (
            <div className="panel mt-3">
              <LoadingState label={`Checking all 30 cameras for ${initial || 'this vehicle'}…`} rows={5} />
            </div>
          )}

          {error && !loading && (
            <div className="panel mt-3">
              <ErrorState message={error} />
            </div>
          )}

          {!loading && !error && searched && result && sightings.length === 0 && (
            <div className="panel mt-3">
              <EmptyState
                title={`No sightings for ${result.plate}`}
                detail="This registration number has not been recorded by any camera in the retained window. Check the format or widen the time range in the Event Explorer."
              />
            </div>
          )}

          {!loading && !error && result && sightings.length > 0 && (
            <>
              {/* Verdict card */}
              <section
                className={`panel mt-3 border-l-4 ${wl?.active ? 'border-l-critical' : 'border-l-online'}`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3 p-3.5">
                  <div>
                    <p className="plate text-2xl text-ink">{prettyPlate(result.plate)}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest">
                      {wl?.active ? (
                        <span className="flex items-center gap-1.5 text-critical">
                          <ShieldAlert size={14} aria-hidden /> Watchlist Match
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 text-online">
                          <ShieldCheck size={15} aria-hidden /> Not on the wanted list
                        </span>
                      )}
                    </p>
                  </div>

                  <dl className="grid grid-cols-2 gap-x-6 gap-y-1.5 sm:grid-cols-4">
                    <div>
                      <dt className="kv-label">Why it is wanted</dt>
                      <dd className="kv-value">{wl?.category ?? '—'}</dd>
                    </div>
                    <div>
                      <dt className="kv-label">Priority</dt>
                      <dd>{wl ? <SeverityChip severity={wl.severity} /> : <span className="kv-value">—</span>}</dd>
                    </div>
                    <div>
                      <dt className="kv-label">Times seen</dt>
                      <dd className="kv-value font-mono tabular-nums">{sightings.length}</dd>
                    </div>
                    <div>
                      <dt className="kv-label">Seen by</dt>
                      <dd className="kv-value font-mono tabular-nums">{result.route?.camerasTouched ?? 0}</dd>
                    </div>
                  </dl>
                </div>

                {wl?.active && (
                  <p className="border-t border-line px-3.5 py-2 text-2xs text-ink-muted">
                    <span className="font-semibold text-ink">{wl.caseRef}</span> · {wl.reason} · Added by{' '}
                    {wl.addedBy} on {formatDateTime(wl.addedAt)}
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-2 border-t border-line px-3.5 py-2.5">
                  <button
                    type="button"
                    className="btn-solid"
                    onClick={() => navigate(`/vehicles/${result.plate}`)}
                  >
                    See where it went <ArrowRight size={14} aria-hidden />
                  </button>
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={() => navigate(`/gis?plate=${result.plate}`)}
                  >
                    <Route size={13} aria-hidden /> Show on map
                  </button>
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={() => navigate(`/events?plate=${result.plate}`)}
                  >
                    Every sighting
                  </button>
                  <span className="ml-auto text-2xs text-ink-faint">
                    First seen {formatDateTime(result.profile?.firstSeen)} · last seen{' '}
                    {formatDateTime(result.profile?.lastSeen)}
                  </span>
                </div>
              </section>

              {/* Sightings list */}
              <Panel
                title={`Sightings — ${sightings.length} records`}
                icon={MapPin}
                className="mt-3"
                actions={
                  <span className="chip border-line bg-surface-3 text-ink-muted">
                    {result.route?.totalDistanceKm ?? 0} km tracked
                  </span>
                }
              >
                <ol className="divide-y divide-line/60">
                  {sightings.map((e, i) => (
                    <li key={e.id} className="flex items-center gap-3 px-3 py-2 hover:bg-surface-2">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-line bg-surface-3 font-mono text-2xs font-bold text-ink-muted">
                        {i + 1}
                      </span>
                      <time className="w-[74px] shrink-0 font-mono text-xs tabular-nums text-ink" dateTime={e.timestamp}>
                        {formatTime(e.timestamp)}
                      </time>
                      <span className="w-[62px] shrink-0 font-mono text-xs text-ink-muted">
                        {e.cameraName ?? e.cameraId.toUpperCase()}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-xs text-ink-muted">{e.location}</span>
                      <span className="hidden font-mono text-2xs tabular-nums text-ink-faint sm:block">
                        {e.plateConfidence.toFixed(1)}%
                      </span>
                      <button
                        type="button"
                        className="btn-ghost btn-xs shrink-0"
                        onClick={() => navigate(`/cameras/${e.cameraId}`)}
                      >
                        Open camera
                      </button>
                    </li>
                  ))}
                </ol>
              </Panel>
            </>
          )}

          {/* Watchlist shortcut */}
          {!result && !loading && (
            <Panel title="Vehicles being watched" icon={ShieldAlert} className="mt-3">
              {watchlist.loading ? (
                <LoadingState label="Loading watchlist" />
              ) : (
                <div className="overflow-x-auto">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th scope="col">Plate</th>
                        <th scope="col">Why it is wanted</th>
                        <th scope="col">Priority</th>
                        <th scope="col">Case number</th>
                        <th scope="col">Added on</th>
                        <th scope="col" className="text-right">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {(watchlist.data ?? [])
                        .filter((w) => w.active)
                        .map((w) => (
                          <tr key={w.id}>
                            <td>
                              <PlateLink plate={w.plate} />
                            </td>
                            <td className="text-ink-muted">{w.category}</td>
                            <td>
                              <SeverityChip severity={w.severity} />
                            </td>
                            <td className="font-mono text-2xs text-ink-muted">{w.caseRef}</td>
                            <td className="text-2xs text-ink-faint">{formatDateTime(w.addedAt)}</td>
                            <td className="text-right">
                              <button
                                type="button"
                                className="btn-primary btn-xs"
                                onClick={() => onTrace(w.plate)}
                              >
                                Find it
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}
