import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="grid h-full place-items-center p-8">
      <div className="panel max-w-md p-6 text-center">
        <Compass size={26} className="mx-auto mb-2 text-ink-faint" aria-hidden />
        <h1 className="text-sm font-bold uppercase tracking-widest text-ink">Route not found</h1>
        <p className="mt-1.5 text-2xs leading-relaxed text-ink-muted">
          This screen does not exist in the Trinetra control room. Return to the Command Center to continue
          your investigation.
        </p>
        <Link to="/" className="btn-primary mt-3">
          Back to Command Center
        </Link>
      </div>
    </div>
  );
}
