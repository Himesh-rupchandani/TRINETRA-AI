import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Activity,
  Bell,
  Cctv,
  Car,
  Map as MapIcon,
  ScanLine,
  ShieldAlert,
  Signal,
  ArrowRight,
} from 'lucide-react';
import { KpiCard } from '@/components/dashboard/KpiCard';
import { CameraActivityChart, DetectionTrend } from '@/components/dashboard/Charts';
import { LiveEventFeed } from '@/components/events/LiveEventFeed';
import { AlertCard } from '@/components/alerts/AlertCard';
import { TraceSearchBar } from '@/components/vehicle/TraceSearchBar';
import { LazyMap } from '@/components/gis/LazyMap';
import { CameraCard } from '@/components/camera/CameraCard';
import { Panel, AsyncBoundary, EmptyState } from '@/components/common/Panel';
import { ServiceStatusChip, StatusChip } from '@/components/common/Chips';
import { useCameras } from '@/hooks/useCameras';
import { useAlerts } from '@/hooks/useAlerts';
import { useAsync } from '@/hooks/useAsync';
import { eventService } from '@/services/eventService';
import { systemService } from '@/services/systemService';
import { formatNumber, formatTime, prettyVehicleClass } from '@/lib/utils';
import { demoFlow } from '@/data/demoFlow';

/**
 * COMMAND CENTER
 * Camera network (left) · live event feed (centre) · active alerts (right),
 * with GIS, trend and system health below. Everything is one click from an
 * investigation.
 */
export default function Dashboard() {
  const navigate = useNavigate();
  const { cameras, stats, loading: camsLoading, error: camsError, refresh } = useCameras();
  const { active: activeAlerts, acknowledge, resolve } = useAlerts();
  const recent = useAsync(() => eventService.recent(120), []);
  const kpis = useAsync(() => systemService.kpis(), []);
  const health = useAsync(() => systemService.health(), []);
  const [previewCamera, setPreviewCamera] = useState<string | null>(null);

  const recentEvents = useMemo(() => recent.data ?? [], [recent.data]);
  const watchCameras = useMemo(
    () => [...cameras].sort((a, b) => (b.eventCount24h ?? 0) - (a.eventCount24h ?? 0)).slice(0, 12),
    [cameras],
  );
  const detectionPoints = useMemo(
    () => recentEvents.filter((e) => e.watchlistMatch).slice(0, 25),
    [recentEvents],
  );

  return (
    <div className="flex flex-col gap-2.5 p-2.5">
      {/* Hero: registration number is always the fastest path into the product */}
      <section className="panel flex flex-col gap-3 p-3 lg:flex-row lg:items-center">
        <div className="lg:max-w-[300px]">
          <h2 className="flex items-center gap-2 text-lg font-bold text-ink">
            <Car size={20} className="text-brand" aria-hidden /> Find a vehicle
          </h2>
          <p className="mt-1 text-sm leading-relaxed text-ink-muted">
            Type a number plate to see every camera that has seen it, when, and where it went.
          </p>
        </div>
        <div className="flex-1">
          <TraceSearchBar onTrace={(p) => navigate(`/vehicles/${p}`)} />
          <nav
            className="mt-3 grid gap-2 border-t border-line pt-3 sm:grid-cols-2 xl:grid-cols-4"
            aria-label="Common tasks"
          >
            {demoFlow.map((task) => (
              <Link
                key={task.step}
                to={task.to}
                className="group flex items-start gap-2.5 rounded-md border border-line bg-surface-2 px-3 py-2.5 transition-colors hover:border-brand/60 hover:bg-brand/5"
              >
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand/12 font-mono text-2xs font-bold text-brand">
                  {task.step}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold text-ink group-hover:text-brand">
                    {task.label}
                  </span>
                  <span className="block text-2xs leading-snug text-ink-faint">{task.hint}</span>
                </span>
              </Link>
            ))}
          </nav>
        </div>
      </section>

      {/* KPI strip */}
      <section
        className="grid grid-cols-2 gap-2.5 sm:grid-cols-3"
        aria-label="Key performance indicators"
      >
        <KpiCard
          label="Cameras in system"
          value={formatNumber(kpis.data?.totalCameras ?? stats.total)}
          sub="Tap to see the full list"
          icon={Cctv}
          to="/registry"
          loading={kpis.loading && camsLoading}
        />
        <KpiCard
          label="Cameras working"
          value={formatNumber(kpis.data?.camerasOnline ?? stats.online)}
          sub={`${stats.degraded} with problems · ${stats.offline} switched off`}
          tone="online"
          icon={Signal}
          to="/cameras"
          loading={kpis.loading && camsLoading}
        />
        <KpiCard
          label="Alerts to action"
          value={formatNumber(activeAlerts.length)}
          sub="Waiting for you"
          tone={activeAlerts.length ? 'critical' : 'neutral'}
          icon={Bell}
          to="/alerts"
        />
        <KpiCard
          label="Vehicles seen"
          value={formatNumber(kpis.data?.vehicleDetections24h)}
          sub="Last 24 hours"
          icon={Car}
          to="/events"
          loading={kpis.loading}
        />
        <KpiCard
          label="Number plates read"
          value={formatNumber(kpis.data?.anprReads24h)}
          sub="Read automatically by the cameras"
          tone="brand"
          icon={ScanLine}
          to="/events"
          loading={kpis.loading}
        />
        <KpiCard
          label="Wanted vehicles found"
          value={formatNumber(kpis.data?.watchlistMatches24h)}
          sub="Last 24 hours"
          tone="critical"
          icon={ShieldAlert}
          to="/alerts"
          loading={kpis.loading}
        />
      </section>

      {/* Main three-column operations row */}
      <section className="grid gap-2.5 xl:grid-cols-12">
        <Panel
          title="Cameras"
          icon={Cctv}
          className="max-h-[720px] xl:col-span-5"
          bodyClassName="overflow-y-auto"
          actions={
            <>
              <span className="chip border-line bg-surface-3 text-ink-muted">
                {stats.online} of {stats.total} working
              </span>
              <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/cameras')}>
                All cameras <ArrowRight size={10} aria-hidden />
              </button>
            </>
          }
        >
          <AsyncBoundary
            loading={camsLoading}
            error={camsError}
            onRetry={refresh}
            isEmpty={!cameras.length}
            loadingLabel="Loading camera registry"
          >
            <div className="grid gap-2 p-2.5 sm:grid-cols-2">
              {watchCameras.map((c) => (
                <CameraCard
                  key={c.id}
                  camera={c}
                  onView={() => setPreviewCamera(c.id)}
                  compact
                  selected={previewCamera === c.id}
                />
              ))}
            </div>
          </AsyncBoundary>
        </Panel>

        <Panel
          title="Vehicles right now"
          icon={Activity}
          className="min-h-[340px] xl:col-span-3"
          bodyClassName="flex flex-col min-h-0"
          actions={
            <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/events')}>
              See all <ArrowRight size={12} aria-hidden />
            </button>
          }
        >
          <LiveEventFeed seed={recentEvents.slice(0, 25)} max={40} />
        </Panel>

        <Panel
          title="Alerts to action"
          icon={Bell}
          className="min-h-[340px] xl:col-span-4"
          bodyClassName="overflow-y-auto"
          actions={
            <>
              <span className="chip border-critical/45 bg-critical/10 text-critical">
                {activeAlerts.length} active
              </span>
              <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/alerts')}>
                All alerts <ArrowRight size={12} aria-hidden />
              </button>
            </>
          }
        >
          {activeAlerts.length === 0 ? (
            <EmptyState title="No active alerts" detail="Nothing needs your attention right now." />
          ) : (
            <div className="space-y-2 p-2.5">
              {activeAlerts.slice(0, 4).map((a) => (
                <AlertCard key={a.id} alert={a} onAcknowledge={acknowledge} onResolve={resolve} compact />
              ))}
            </div>
          )}
        </Panel>
      </section>

      {/* Bottom row: GIS · trend · health */}
      <section className="grid gap-2.5 xl:grid-cols-12">
        <Panel
          title="Where vehicles are being seen"
          icon={MapIcon}
          className="min-h-[320px] xl:col-span-5"
          bodyClassName="relative"
          actions={
            <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/gis')}>
              Full map <ArrowRight size={10} aria-hidden />
            </button>
          }
        >
          <LazyMap
            cameras={cameras}
            events={detectionPoints}
            className="absolute inset-0"
            onSelectCamera={(c) => navigate(`/cameras/${c.id}`)}
            zoom={11}
          />
        </Panel>

        <div className="grid gap-2.5 xl:col-span-4">
          <Panel title="Vehicles seen each hour" icon={Activity} className="min-h-[160px]" bodyClassName="p-1.5">
            <div className="h-[130px]">
              <DetectionTrend events={recentEvents} />
            </div>
          </Panel>
          <Panel title="Busiest cameras" icon={Cctv} className="min-h-[160px]" bodyClassName="p-1.5">
            <div className="h-[150px]">
              <CameraActivityChart events={recentEvents} />
            </div>
          </Panel>
        </div>

        <Panel
          title="Is everything working?"
          icon={Activity}
          className="xl:col-span-3"
          actions={
            <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/system')}>
              Details <ArrowRight size={10} aria-hidden />
            </button>
          }
        >
          <AsyncBoundary loading={health.loading} error={health.error} onRetry={health.refresh}>
            <ul className="divide-y divide-line/60">
              {(health.data?.services ?? []).map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2 px-2.5 py-1.5">
                  <div className="min-w-0">
                    <p className="truncate text-xs text-ink">{s.name}</p>
                    <p className="text-[10px] text-ink-faint">
                      {s.uptimePct.toFixed(2)}% · hb {formatTime(s.lastHeartbeat)}
                    </p>
                  </div>
                  <ServiceStatusChip status={s.status} />
                </li>
              ))}
            </ul>
          </AsyncBoundary>
        </Panel>
      </section>

      {/* Recent detections table */}
      <Panel
        title="Latest vehicles seen"
        icon={ScanLine}
        actions={
          <button type="button" className="btn-ghost btn-xs" onClick={() => navigate('/events')}>
            Open Event See all <ArrowRight size={12} aria-hidden />
          </button>
        }
      >
        <AsyncBoundary loading={recent.loading} error={recent.error} onRetry={recent.refresh}>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Time</th>
                  <th scope="col">Camera</th>
                  <th scope="col">Place</th>
                  <th scope="col">Plate</th>
                  <th scope="col">Vehicle type</th>
                  <th scope="col">Plate match</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentEvents.slice(0, 8).map((e) => (
                  <tr
                    key={e.id}
                    className="cursor-pointer"
                    onClick={() => navigate(`/vehicles/${e.plate}`)}
                  >
                    <td className="font-mono tabular-nums text-ink-muted">{formatTime(e.timestamp)}</td>
                    <td className="font-mono text-ink-muted">{e.cameraName}</td>
                    <td className="max-w-[220px] truncate text-ink-muted">{e.location}</td>
                    <td className="plate text-ink">{e.plate}</td>
                    <td className="text-ink-muted">{prettyVehicleClass(e.vehicleClass)}</td>
                    <td className="font-mono tabular-nums text-ink-muted">
                      {e.plateConfidence ? `${e.plateConfidence.toFixed(1)}%` : '—'}
                    </td>
                    <td>
                      {e.watchlistMatch ? (
                        <span className="chip border-critical/45 bg-critical/10 text-critical">Watchlist</span>
                      ) : (
                        <StatusChip status="ONLINE" showDot={false} />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </AsyncBoundary>
      </Panel>
    </div>
  );
}
